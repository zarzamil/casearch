import test from 'node:test';
import assert from 'node:assert/strict';
import {
  GENUINE_IMPORTED_EVIDENCE,
  GENUINE_IMPORTED_DOCUMENT_INDEX
} from '../src/data/bahrainPilot';
import { EvidenceItem, DocumentIndexItem } from '../src/types';
import {
  matchOcrRecoveryTarget,
  applyOcrRecoveryToRecord,
  reconcileDuplicates,
  normalizeFilename,
  scoreRecordCompleteness
} from '../src/utils/ocrRecovery';

test('OCR Recovery Duplicate Handling & Invariant Preservation', async (t) => {
  // Setup baseline evidence items (13 genuine records)
  const baseEvidence: EvidenceItem[] = JSON.parse(JSON.stringify(GENUINE_IMPORTED_EVIDENCE));
  const baseIndex: DocumentIndexItem[] = JSON.parse(JSON.stringify(GENUINE_IMPORTED_DOCUMENT_INDEX));

  await t.test('1. Match by SHA-256 hash first to an OCR_REQUIRED record returns OCR_RECOVERY_UPDATE', () => {
    // Attach a mock hash to contract.pdf (EX-REAL-09, which is OCR_REQUIRED)
    const targetExhibit = baseEvidence.find(e => e.filename === 'contract.pdf')!;
    assert.equal(targetExhibit.ocr_status, 'OCR_REQUIRED');
    targetExhibit.file_hash = 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855';

    const match = matchOcrRecoveryTarget(
      {
        name: 'different_filename_uploaded.pdf',
        hash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
      },
      baseEvidence
    );

    assert.equal(match.isMatch, true);
    assert.equal(match.matchType, 'HASH');
    assert.equal(match.target?.exhibit_id, 'EX-REAL-09');
    assert.equal(match.isOcrRequired, true);
    assert.equal(match.action, 'OCR_RECOVERY_UPDATE');
  });

  await t.test('2. Match by normalized filename to an OCR_REQUIRED record returns OCR_RECOVERY_UPDATE', () => {
    // Select contract.pdf with mixed case and whitespace
    const match = matchOcrRecoveryTarget(
      { name: '  CONTRACT.pdf  ' },
      baseEvidence
    );

    assert.equal(match.isMatch, true);
    assert.equal(match.matchType, 'FILENAME');
    assert.equal(match.target?.exhibit_id, 'EX-REAL-09');
    assert.equal(match.isOcrRequired, true);
    assert.equal(match.action, 'OCR_RECOVERY_UPDATE');
  });

  await t.test('3. Match to an already completed record returns REJECT_DUPLICATE', () => {
    // Select MOJ-E-BKPZAUXTMOHLMMX.pdf which is already completed
    const match = matchOcrRecoveryTarget(
      { name: 'MOJ-E-BKPZAUXTMOHLMMX.pdf' },
      baseEvidence
    );

    assert.equal(match.isMatch, true);
    assert.equal(match.isOcrRequired, false);
    assert.equal(match.action, 'REJECT_DUPLICATE');
    assert.ok(match.reason.includes('already exists in Evidence Vault'));
  });

  await t.test('4. Selected PDF bytes update existing OCR_REQUIRED record while strictly preserving invariants', () => {
    const originalContract = baseEvidence.find(e => e.filename === 'contract.pdf')!;
    assert.equal(originalContract.exhibit_id, 'EX-REAL-09');
    assert.equal(originalContract.page_count, 5);
    assert.equal(originalContract.data_origin, 'USER_IMPORTED');
    assert.equal(originalContract.authentication_status, 'UNVERIFIED');
    assert.equal(originalContract.raw_text, undefined);

    const recoveredOcrText = `p.1: عقد إيجار عقار سكني موحد - مملكة البحرين
المؤجر: مبارك علي جودر
المستأجر: ألينا أليكسيفا
الأجرة الشهرية: 360 دينار بحريني
تاريخ بدء الإيجار: 01/01/2026
p.2: شروط العقد والتزامات الطرفين...
p.3: الرسوم ومسؤوليات الصيانة...
p.4: شروط الإخلاء وتسليم العين المؤجرة...
p.5: توقيعات الطرفين وتصديق المحررات`;

    const updated = applyOcrRecoveryToRecord(originalContract, {
      raw_text: recoveredOcrText,
      usable_coverage_percent: 100,
      usable_pages: [1, 2, 3, 4, 5],
      failed_pages: [],
      ocr_status: 'COMPLETED',
      completeness_status: 'COMPLETE',
      file_hash: 'a1b2c3d4e5f67890123456789abcdef0123456789abcdef0123456789abcdef0'
    });

    // Invariants MUST be strictly preserved
    assert.equal(updated.id, originalContract.id, 'Record ID must be preserved');
    assert.equal(updated.exhibit_id, 'EX-REAL-09', 'Exhibit ID EX-REAL-09 must be preserved');
    assert.equal(updated.data_origin, 'USER_IMPORTED', 'data_origin must remain USER_IMPORTED');
    assert.equal(updated.authentication_status, 'UNVERIFIED', 'authentication_status must remain UNVERIFIED');
    assert.equal(updated.filename, 'contract.pdf', 'Original filename contract.pdf must be retained');
    assert.equal(updated.page_count, 5, 'Original page count of 5 pages must be retained');

    // Recovery fields MUST be updated
    assert.equal(updated.ocr_status, 'COMPLETED');
    assert.equal(updated.completeness_status, 'COMPLETE');
    assert.equal(updated.raw_text, recoveredOcrText);
    assert.equal(updated.usable_coverage_percent, 100);
    assert.equal(updated.usable_pages_count, 5);
    assert.equal(updated.failed_pages_count, 0);
    assert.ok(updated.notes.includes('OCR RECOVERY COMPLETED'));
  });

  await t.test('5. In-place update creates NO new Evidence Vault or Document Index records', () => {
    const evidenceList: EvidenceItem[] = JSON.parse(JSON.stringify(GENUINE_IMPORTED_EVIDENCE));
    const documentIndex: DocumentIndexItem[] = JSON.parse(JSON.stringify(GENUINE_IMPORTED_DOCUMENT_INDEX));
    const initialEvidenceCount = evidenceList.length;
    const initialIndexCount = documentIndex.length;

    // Simulate in-place update for execution full file.pdf (EX-REAL-10, 65 pages)
    const targetIdx = evidenceList.findIndex(e => e.exhibit_id === 'EX-REAL-10');
    assert.ok(targetIdx !== -1);

    const updatedTarget = applyOcrRecoveryToRecord(evidenceList[targetIdx], {
      raw_text: 'p.1: محكمة التنفيذ - ملف التنفيذ الكامل رقم 042026162064...',
      ocr_status: 'COMPLETED',
      usable_coverage_percent: 100
    });

    // In-place replacement
    evidenceList[targetIdx] = updatedTarget;

    // Document index in-place update
    const docIdx = documentIndex.findIndex(d => d.exhibit_id === 'EX-REAL-10');
    assert.ok(docIdx !== -1);
    documentIndex[docIdx] = {
      ...documentIndex[docIdx],
      is_readable: true,
      ocr_required: false,
      evidentiary_significance: 'OCR recovered from authentic user PDF bytes.'
    };

    // Assert counts are unchanged
    assert.equal(evidenceList.length, initialEvidenceCount, 'Evidence Vault count must remain 13');
    assert.equal(documentIndex.length, initialIndexCount, 'Document Index count must remain 13');
  });

  await t.test('6. Duplicate reconciliation retains record with superior provenance/OCR text and logs audit', () => {
    // Create an artificial duplicate scenario:
    // Superior record: has 1,200 chars of OCR text, COMPLETED status, complete notes
    const superiorItem: EvidenceItem = {
      ...baseEvidence[8], // contract.pdf
      id: 'EV_SUPERIOR_01',
      exhibit_id: 'EX-REAL-09',
      filename: 'contract.pdf',
      raw_text: 'p.1: عقد إيجار كامل ومفصل...'.repeat(20),
      ocr_status: 'COMPLETED',
      completeness_status: 'COMPLETE',
      notes: 'Authentic contract with verified terms'
    };

    // Inferior duplicate: duplicate filename, 0 text, OCR_REQUIRED
    const inferiorItem: EvidenceItem = {
      ...baseEvidence[8],
      id: 'EV_INFERIOR_DUP',
      exhibit_id: 'EX-REAL-DUP',
      filename: 'contract.pdf',
      raw_text: undefined,
      ocr_status: 'OCR_REQUIRED',
      completeness_status: 'PARTIAL',
      notes: 'Incomplete duplicate record'
    };

    const duplicateEvidence = [...baseEvidence, inferiorItem];
    // Replace contract.pdf with superior
    duplicateEvidence[8] = superiorItem;

    const duplicateIndex: DocumentIndexItem[] = [
      ...baseIndex,
      {
        id: 'DOC_DUP_01',
        exhibit_id: 'EX-REAL-DUP',
        page_number: 1,
        document_title: 'contract.pdf',
        document_category: 'Duplicate',
        is_original: false,
        is_readable: false,
        ocr_required: true,
        data_origin: 'USER_IMPORTED',
        evidentiary_significance: 'Inferior duplicate'
      }
    ];

    assert.equal(duplicateEvidence.length, 14);
    assert.equal(duplicateIndex.length, 14);

    const { reconciledEvidence, reconciledIndex, removedAuditLogs } = reconcileDuplicates(
      duplicateEvidence,
      duplicateIndex
    );

    // Only inferior duplicate is removed; superior is retained
    assert.equal(reconciledEvidence.length, 13);
    assert.equal(reconciledIndex.length, 13);
    assert.equal(reconciledEvidence.some(e => e.id === 'EV_INFERIOR_DUP'), false);
    assert.equal(reconciledEvidence.some(e => e.id === 'EV_SUPERIOR_01'), true);

    // Audit log recorded
    assert.equal(removedAuditLogs.length, 1);
    assert.equal(removedAuditLogs[0].removed_id, 'EV_INFERIOR_DUP');
    assert.equal(removedAuditLogs[0].removed_exhibit_id, 'EX-REAL-DUP');
    assert.equal(removedAuditLogs[0].retained_exhibit_id, 'EX-REAL-09');
    assert.ok(removedAuditLogs[0].reason.includes('Removed inferior duplicate record'));
  });

  await t.test('7. Duplicate reconciliation by SHA-256 hash retains superior record', () => {
    const testHash = '5f4dcc3b5aa765d61d8327deb882cf992b9699aaf4c4ac47b2c53f44cdADC254';

    const itemA: EvidenceItem = {
      ...baseEvidence[0],
      id: 'EV_A',
      exhibit_id: 'EX-01-A',
      filename: 'file_version_1.pdf',
      file_hash: testHash,
      raw_text: 'Text content p.1',
      ocr_status: 'COMPLETED',
      completeness_status: 'COMPLETE'
    };

    const itemB: EvidenceItem = {
      ...baseEvidence[0],
      id: 'EV_B',
      exhibit_id: 'EX-01-B',
      filename: 'file_version_2_renamed.pdf',
      file_hash: testHash, // Same hash, different filename
      raw_text: undefined,
      ocr_status: 'OCR_REQUIRED',
      completeness_status: 'PARTIAL'
    };

    const testList = [itemA, itemB];
    const { reconciledEvidence, removedAuditLogs } = reconcileDuplicates(testList);

    assert.equal(reconciledEvidence.length, 1);
    assert.equal(reconciledEvidence[0].id, 'EV_A', 'Superior record with completed OCR must be retained');
    assert.equal(removedAuditLogs.length, 1);
    assert.ok(removedAuditLogs[0].reason.includes('identical SHA-256 file hash'));
  });
});
